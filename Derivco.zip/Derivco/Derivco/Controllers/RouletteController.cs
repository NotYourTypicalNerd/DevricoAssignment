using Infrastructure.Abstractions;
using Infrastructure.Domains;
using Microsoft.AspNetCore.Mvc;

namespace Derivco.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RouletteController : ControllerBase
    {
        private readonly ILogger<RouletteController> _logger;
        private readonly IRouletteRepository _rouletteRepository;

        public RouletteController(ILogger<RouletteController> logger, IRouletteRepository rouletteRepository)
        {
            _logger = logger;
            _rouletteRepository = rouletteRepository;
        }

        //get api/roulette/getroulettes
        [HttpGet("GetRoulettes")]
        public async Task<ActionResult<Roulette>> GetRoulettes()
        {
            var model = await _rouletteRepository.GetRoulettes();
            return Ok(model);
        }

        //get api/roulette/getplayers
        [HttpGet("getplayers")]
        public async Task<ActionResult<Players>> GetPlayers()
        {
            var model = await _rouletteRepository.GetPlayers();
            return Ok(model);
        }


        // POST api/<RouletteController>/creategame
        [HttpPost("creategame")]
        public async Task<IActionResult> CreateGame([FromBody] int RouletteId)
        {
            if (RouletteId == 0)
            {
                return BadRequest();
            }

            var model = await _rouletteRepository.CreateGame(RouletteId);
            return Ok(model);
        }

        /// <summary>
        /// This can arguably use Roulette ID or GameId, but for simplicity will go with GameID
        /// 
        /// </summary>
        /// <param name="GameId"></param>
        /// <returns></returns>
        // Put api/<RouletteController>/spin
        [HttpPut("spin")]
        public async Task<IActionResult> Spin([FromBody] int GameId)
        {
            if (GameId == 0)
            {
                return BadRequest();
            }

            var model = await _rouletteRepository.Spin(GameId);
            return Ok(model);
        }


        /// <summary>
        /// This endpoint return previous spins for a given roulette machine.
        /// </summary>
        /// <param name="Id">This is Roulette ID</param>
        /// <returns></returns>
        // GET api/roulette/games/{Id}
        [HttpGet("games/{Id}")]
        public async Task<IActionResult> Get(int Id)
        {
            if (Id == 0)
            {
                return BadRequest();
            }

            var model = await _rouletteRepository.GetGames(Id);
            return Ok(model);
        }

        // POST api/<RouletteController>/bet
        [HttpPost("bet")]
        public async Task<IActionResult> bet(Bet bet)
        {
            if (bet.PlayerID == 0 || bet.GameId == 0 || bet.AmountWagered == 0)
            {
                return BadRequest();
            }

            await _rouletteRepository.PlaceBet(bet);

            return Ok("Bet placed");
        }

    }
}