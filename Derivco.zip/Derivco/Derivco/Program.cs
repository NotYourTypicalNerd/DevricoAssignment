using Infrastructure;
using Infrastructure.Abstractions;
using Infrastructure.Implementations;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<DapperContext>();
builder.Services.AddControllers();

builder.Services.AddScoped<IRouletteRepository, RouletteRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.

app.UseAuthorization();

app.MapControllers();

app.Run();
