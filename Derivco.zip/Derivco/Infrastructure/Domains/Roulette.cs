﻿namespace Infrastructure.Domains
{
    public class Roulette
    {
        public int Id { get; set; }
        public required string Name { get; set; }

    }
}