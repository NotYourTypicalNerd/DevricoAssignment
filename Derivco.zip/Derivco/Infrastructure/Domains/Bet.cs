﻿namespace Infrastructure.Domains
{
    public class Bet
    {
        public int Id { get; set; }
        public int GameId { get; set; }
        public int PlayerID { get; set; }
        public decimal AmountWagered { get; set; }
        public int Number { get; set; }
        public bool IsProcessed {  get; set; }
    }
}
