﻿namespace Infrastructure
{
    public static class Helpers
    {
        public static int GetRandomNumber(int start, int end)
        {
            Random random = new Random();
            return random.Next(start, end+1);
        }
    }
}
