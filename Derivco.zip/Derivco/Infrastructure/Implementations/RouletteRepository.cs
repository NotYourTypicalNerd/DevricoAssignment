﻿using Dapper;
using Infrastructure.Abstractions;
using Infrastructure.Domains;

namespace Infrastructure.Implementations
{
    /// <summary>
    /// Ideally, these should be separated into their own little respositories per table, but I am loathe to create
    /// unnecessary work that goes beyond the scope of this task. This possible violates Single Responsibily pattern, 
    /// but I think I can take the risk as the scope for this task is not clear and I dont want an 'overkill' solution
    /// </summary>
    public class RouletteRepository : IRouletteRepository
    {
        private readonly DapperContext _context;
        public RouletteRepository(DapperContext context)
        {
            _context = context;
        }

        public async Task<int> CreateGame(int RouletteID)
        {
            var query = @"INSERT INTO Games(RouletteId) VALUES " +
                        " (@RouletteID);";
            using (var connection = _context.CreateConnection())
            {
                var gameID = await connection.QueryAsync<int>(query, new { RouletteID });
                string sql = @"select last_insert_rowid()";
                return (int)connection.ExecuteScalar(sql);
            }
        }

        public async Task<List<Game>> GetGames(int RouletteId)
        {
            var query = "SELECT * FROM Games where RouletteId = @RouletteId";

            using (var connection = _context.CreateConnection())
            {
                var gameID = await connection.QueryAsync<Game>(query, new { RouletteId });
                return gameID.ToList();
            }
        }

        //use this to ensure player exist
        public async Task<Players> GetPlayer(int Id)
        {
            var query = "SELECT * FROM Players where @Id=Id";
            using (var connection = _context.CreateConnection())
            {
                var player = await connection.QuerySingleAsync<Players>(query, new { Id });
                return player;
            }
        }

        public async Task<List<Players>> GetPlayers()
        {
            var query = "SELECT * FROM Players";
            using (var connection = _context.CreateConnection())
            {
                var players = await connection.QueryAsync<Players>(query);
                return players.ToList();
            }
        }

        public async Task<Roulette> GetRoulette(int Id)
        {
            var query = "SELECT * FROM Roulettes where @Id=Id";
            using (var connection = _context.CreateConnection())
            {
                var roulettes = await connection.QuerySingleAsync<Roulette>(query, new { Id });
                return roulettes;
            }
        }

        public async Task<List<Roulette>> GetRoulettes()
        {
            var query = "SELECT * FROM Roulettes";
            using (var connection = _context.CreateConnection())
            {
                var roulettes = await connection.QueryAsync<Roulette>(query);
                return roulettes.ToList();
            }
        }

        /// <summary>
        /// For each given GameID, find the WinningNumber in the corresponding Game Table
        /// The, For each bet, if the player's number matches the one on the game, the pay the player.
        /// </summary>
        /// <param name="GameId"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public Task<int> PayOut(int GameId)
        {
            //not implemented for brevity
            throw new NotImplementedException();
        }

        public async Task PlaceBet(Bet bet)
        {
            using var connection = _context.CreateConnection();
            var sql = """
            INSERT INTO Bet (GameId, PlayerID, AmountWagered, Number)
            VALUES (@GameId, @PlayerID, @AmountWagered, @Number)
            """;

            await connection.ExecuteAsync(sql, bet);
        }

        public async Task<int> Spin(int Id)
        {
            var WinningNumber = Helpers.GetRandomNumber(0, 36);
            var query = "Update Games set WinningNumber=@WinningNumber where Id=@Id";
            using (var connection = _context.CreateConnection())
            {
                var player = await connection.QuerySingleAsync<Players>(query, new { WinningNumber, Id });
                return 0;
            }
        }

    }
}
