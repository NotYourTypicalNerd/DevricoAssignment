﻿using Infrastructure.Domains;

namespace Infrastructure.Abstractions
{
    //this interface can be broken to map each Table to its own interface but this seem like an overkill for this simple task
    public interface IRouletteRepository
    {
        /// <summary>
        /// Get all existing player IDs. Since the scope of this task is not to add new players, this
        /// Just ensure that only existing Ids can be used
        /// </summary>
        /// <returns></returns>
        public Task<List<Players>> GetPlayers();

        /// <summary>
        /// Used to confirm that the PlayerId in the request body indeed exist
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Task<Players> GetPlayer(int ID);

        /// <summary>
        /// Entry point to find the correct Id for existing Roulettes
        /// </summary>
        /// <returns></returns>
        public Task<List<Roulette>> GetRoulettes();

        /// <summary>
        /// individual roulette id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<Roulette> GetRoulette(int id);

        /// <summary>
        /// Pass the Id of the Roulette to find the results of all previous spins
        /// </summary>
        /// <param name="rouletteID"></param>
        /// <returns></returns>
        public Task<List<Game>> GetGames(int rouletteID);

        /// <summary>
        /// Only game we are playing is setting the number. All other bets(color, even number, etc) are not necesary for the scope
        /// of this test
        /// </summary>
        /// <param name="GameID"></param>
        /// <returns></returns>
        public Task<int> Spin(int GameID);

        /// <summary>
        /// Submit bet for a single player toward one game. 
        /// Would have loved to do: validation to ensure that player and GameID indeed exists. Running out of time
        /// </summary>
        /// <param name="bet"></param>
        /// <returns></returns>
        public Task PlaceBet(Bet bet);

        /// <summary>
        /// After grabbing the Roulette ID, this method must be called to create a game.
        /// I am making an assumption that one Roulette wont have two games at a Time and will only create this
        /// If the WinningNumber is not set in the latest Row for this Roulette in the Game Table
        /// </summary>
        /// <param name="rouletteID"></param>
        /// <returns></returns>
        public Task<int> CreateGame(int rouletteID);

        /// <summary>
        /// Game must have already spinned and for each bet matching the chosen number from the spin, pay according to 
        /// warger amount at odds of 35:1. That is, multiply the wager amount by 35
        /// </summary>
        /// <param name="GameId"></param>
        /// <returns></returns>
        public Task<int> PayOut(int GameId);

    }
}
